from fastapi import APIRouter
from schemas import ProjectCreate, ProjectResponse, ProjectUpdate
from routers.projects.create_project import create_project
from routers.projects.get_all_projects import get_all_projects
from routers.projects.get_project_by_id import get_project_by_id
from routers.projects.get_projects_by_employee import get_projects_by_employee
from routers.projects.update_project import updateProject
from routers.projects.delete_project import deleteProject

router = APIRouter(prefix="/projects", tags=["Projects"])

@router.get("/get", response_model=list[ProjectResponse])
def getProjects():
    return get_all_projects()

@router.get("/get/{id}", response_model=ProjectResponse)
def getProjectById(id: int):
    return get_project_by_id(id)

@router.get("/employee/{employee_id}", response_model=list[ProjectResponse])
def getProjectsByEmployee(employee_id: int):
    return get_projects_by_employee(employee_id)

@router.post("/add", response_model=ProjectResponse)
def addProject(project: ProjectCreate):
    return create_project(project)

@router.put("/update/{id}")
def update_project(id: int, project: ProjectUpdate):
    return updateProject(id, project)

@router.delete("/delete/{id}")
def delete_project(id: int):
    return deleteProject(id)
