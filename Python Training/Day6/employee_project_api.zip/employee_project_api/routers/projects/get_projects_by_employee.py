from db_connection import LocalSession
from models import Project
from sqlalchemy import select
from fastapi import HTTPException

def get_projects_by_employee(employee_id: int):
    session = LocalSession()
    try:
        query = select(Project).where(Project.employee_id == employee_id)
        projects = session.scalars(query).all()
        return projects
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()
