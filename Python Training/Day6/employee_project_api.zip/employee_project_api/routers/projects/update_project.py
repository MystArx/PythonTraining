from db_connection import LocalSession
from models import Project
from sqlalchemy import update
from schemas import ProjectUpdate
from fastapi import HTTPException

def updateProject(id: int, project: ProjectUpdate):
    session = LocalSession()
    try:
        project_check = session.get(Project, id)

        if project_check is None:
            raise HTTPException(status_code=404, detail="Project not found")

        update_data = project.model_dump(exclude_unset=True)
        if update_data:
            query = update(Project).where(Project.project_id == id).values(**update_data)
            session.execute(query)
            session.commit()

        return {
            "message": "Updated"
        }
    except HTTPException:
        session.rollback()
        raise
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()
