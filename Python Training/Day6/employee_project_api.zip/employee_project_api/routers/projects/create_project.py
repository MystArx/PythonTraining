from fastapi import HTTPException
from db_connection import LocalSession
from models import Project, Employee
from schemas import ProjectCreate

def create_project(project: ProjectCreate):
    session = LocalSession()
    try:
        employee = session.get(Employee, project.employee_id)
        if not employee:
            raise HTTPException(status_code=404, detail="Employee not found")

        new_project = Project(
            project_name=project.project_name,
            project_description=project.project_description or "",
            project_status=project.project_status,
            employee_id=project.employee_id
        )
        session.add(new_project)
        session.commit()
        session.refresh(new_project)
        return new_project
    except HTTPException:
        session.rollback()
        raise
    except Exception as e:
        session.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        session.close()
