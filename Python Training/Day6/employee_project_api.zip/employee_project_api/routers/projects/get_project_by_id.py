from db_connection import LocalSession
from models import Project
from fastapi import HTTPException

def get_project_by_id(id: int):
    session = LocalSession()
    try:
        project = session.get(Project, id)
        if project is None:
            raise HTTPException(status_code=404, detail="Project not found")
        return project
    finally:
        session.close()
