from pydantic import BaseModel, EmailStr, ConfigDict
from typing import Optional

class ProjectCreate(BaseModel):
    project_name: str
    project_description: Optional[str] = None
    project_status: str
    employee_id: int

class ProjectUpdate(BaseModel):
    project_name: Optional[str] = None
    project_description: Optional[str] = None
    project_status: Optional[str] = None
    employee_id: Optional[int] = None
    
    
class ProjectResponse(BaseModel):
    project_id: int
    project_name: str
    project_description: Optional[str] = None
    project_status: str 
    employee_id: int

    model_config = ConfigDict(from_attributes=True)


#-------------------------------------------------------------------------------------------------------------------


class EmployeeCreate(BaseModel):
    employee_name: str
    employee_email: EmailStr
    employee_department: str
    employee_salary: float


class EmployeeUpdate(BaseModel):
    employee_name: Optional[str] = None
    employee_email: Optional[EmailStr] = None
    employee_department: Optional[str] = None
    employee_salary: Optional[float] = None


class EmployeeResponse(BaseModel):
    employee_id: int
    employee_name: str
    employee_email: str
    employee_department: str
    employee_salary: float
    model_config = ConfigDict(from_attributes=True)


class EmployeeResponseWithProject(BaseModel):
    employee_id: int
    employee_name: str
    employee_email: EmailStr
    employee_department: str
    employee_salary: float

    projects: list[ProjectResponse] = []
    model_config = ConfigDict(from_attributes=True)
