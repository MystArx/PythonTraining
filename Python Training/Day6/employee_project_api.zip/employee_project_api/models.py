from db_connection import Base
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

class Employee(Base):
    __tablename__ = "employees"

    employee_id = Column(Integer, primary_key=True, autoincrement=True)
    employee_name = Column(String(50), nullable=False)
    employee_email = Column(String(100), nullable=False, unique=True)
    employee_department = Column(String(50), nullable=False)
    employee_salary = Column(Integer, nullable=False)

    projects = relationship("Project", backref="employee", cascade="all, delete-orphan")


class Project(Base):
    __tablename__ = "projects"

    project_id = Column(Integer, primary_key=True, autoincrement=True)
    project_name = Column(String(50), nullable=False)
    project_description = Column(String(100), nullable=False)
    project_status = Column(String(50), nullable=False)
    employee_id = Column(Integer, ForeignKey("employees.employee_id"), nullable=False)