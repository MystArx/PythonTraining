from fastapi import FastAPI
from database.create_tables import create_tables
from pipeline.run_pipeline import run_pipeline

from api.customer_routes import router as customer_router
from api.account_routes import router as account_router
from api.branch_routes import router as branch_router
from api.transaction_routes import router as transaction_router
from api.loan_routes import router as loan_router
from api.analytics_routes import router as analytics_router
from api.chart_routes import router as chart_router
from api.pipeline_routes import router as pipeline_router
from api.rejected_routes import router as rejected_router
#from api.agent_routes import router as agent_router

app = FastAPI(
    title="Enterprise Banking Transaction, Customer & Fraud Analytics Platform",
    description="Enterprise Banking Data Engineering Platform with FastAPI, SQLAlchemy, Pandas, Matplotlib and Ollama AI Agent.",
    version="1.1.0"
)

# Include Routers
app.include_router(customer_router)
app.include_router(account_router)
app.include_router(branch_router)
app.include_router(transaction_router)
app.include_router(loan_router)
app.include_router(analytics_router)
app.include_router(chart_router)
app.include_router(pipeline_router)
app.include_router(rejected_router)
#app.include_router(agent_router)

@app.on_event("startup")
def startup_event():
    create_tables()

@app.get("/")
def read_root():
    return {
        "message": "Welcome to Enterprise Banking Analytics Platform API",
        "docs": "/docs",
        "redoc": "/redoc"
    }

if __name__ == "__main__":
    create_tables()
    run_pipeline()
