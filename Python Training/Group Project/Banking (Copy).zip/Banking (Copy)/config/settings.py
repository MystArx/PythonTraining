import os
#from dotenv import load_dotenv

BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# load_dotenv(os.path.join(BASE_DIR, ".env"))

db_host="localhost"
db_username="root"
db_password="password"
db_port=3306
db_name="banking_enterprise_db"

CUSTOMERS_FILE=os.path.join(BASE_DIR,"data","input","customers.csv")
ACCOUNTS_FILE=os.path.join(BASE_DIR,"data","input","accounts.csv")
BRANCHES_FILE=os.path.join(BASE_DIR,"data","input","branches.csv")
TRANSACTIONS_FILE=os.path.join(BASE_DIR,"data","input","transactions.csv")
LOANS_FILE=os.path.join(BASE_DIR,"data","input","loans.csv")

REJECTED_FOLDER=os.path.join(BASE_DIR,"data","rejected")
INPUT_FOLDER=os.path.join(BASE_DIR,"data","input")
PROCESSED_FOLDER=os.path.join(BASE_DIR,"data","processed")
ARCHIVE_FOLDER=os.path.join(BASE_DIR,"data","archive")

os.makedirs(REJECTED_FOLDER,exist_ok=True)
os.makedirs(INPUT_FOLDER,exist_ok=True)
os.makedirs(PROCESSED_FOLDER,exist_ok=True)
os.makedirs(ARCHIVE_FOLDER,exist_ok=True)

REJECTED_CUSTOMERS_FILE=os.path.join(REJECTED_FOLDER,"rejected_customers.csv")
REJECTED_ACCOUNTS_FILE=os.path.join(REJECTED_FOLDER,"rejected_accounts.csv")
REJECTED_BRANCHES_FILE=os.path.join(REJECTED_FOLDER,"rejected_branches.csv")
REJECTED_TRANSACTIONS_FILE=os.path.join(REJECTED_FOLDER,"rejected_transactions.csv")
REJECTED_LOANS_FILE=os.path.join(REJECTED_FOLDER,"rejected_loans.csv")

CHART_OUTPUT_DIR=os.path.join(BASE_DIR,"chart_output")
os.makedirs(CHART_OUTPUT_DIR,exist_ok=True)

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
DEFAULT_GROQ_MODEL = "openai/gpt-oss-20b"
DEFAULT_OLLAMA_MODEL = "qwen3:4b"
