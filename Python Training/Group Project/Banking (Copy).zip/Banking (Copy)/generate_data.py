import csv
import random
import os
from datetime import datetime,timedelta

BASE_DIR=os.path.dirname(os.path.abspath(__file__))
INPUT_DIR=os.path.join(BASE_DIR,"data","input")
os.makedirs(INPUT_DIR,exist_ok=True)

random.seed(42)

# ─── Helper Data ─────────────────────────────────────────────────────────────

FIRST_NAMES=["Rahul","Priya","Ankit","Sneha","Vikram","Neha","Rohan","Kavita","Amit","Pooja",
             "Suresh","Deepa","Manoj","Swati","Rajesh","Aarti","Sanjay","Meena","Arjun","Ritu",
             "Karan","Nisha","Vishal","Pallavi","Arun","Shweta","Nikhil","Divya","Gaurav","Anjali",
             "Mohit","Sakshi","Pranav","Isha","Tushar","Ritika","Varun","Megha","Harsh","Sonali",
             "Dhruv","Tanvi","Kunal","Bhavna","Tarun","Shruti","Ashish","Preeti","Vivek","Komal"]

LAST_NAMES=["Sharma","Verma","Gupta","Singh","Kumar","Patel","Joshi","Mehta","Reddy","Nair",
            "Iyer","Rao","Das","Chatterjee","Banerjee","Mukherjee","Mishra","Pandey","Saxena","Agarwal",
            "Tiwari","Chauhan","Yadav","Jain","Shah","Malhotra","Kapoor","Bhat","Nayak","Menon"]

CITIES=["Mumbai","Delhi","Bangalore","Hyderabad","Chennai","Kolkata","Pune","Ahmedabad","Jaipur","Lucknow",
        "Noida","Gurugram","Chandigarh","Indore","Bhopal","Nagpur","Patna","Coimbatore","Kochi","Surat"]

STATES=["Maharashtra","Delhi","Karnataka","Telangana","Tamil Nadu","West Bengal","Maharashtra","Gujarat",
        "Rajasthan","Uttar Pradesh","Uttar Pradesh","Haryana","Punjab","Madhya Pradesh","Madhya Pradesh",
        "Maharashtra","Bihar","Tamil Nadu","Kerala","Gujarat"]

CUSTOMER_TYPES=["Regular","Premium","Corporate"]
ACCOUNT_TYPES=["Savings","Current","Salary","Business"]
TRANSACTION_TYPES=["CREDIT","DEBIT"]
TRANSACTION_MODES=["UPI","ATM","Debit Card","Credit Card","Net Banking","Mobile Banking"]
LOAN_TYPES=["Home Loan","Personal Loan","Car Loan","Education Loan","Business Loan"]
LOAN_STATUSES=["Active","Closed","Defaulted"]
MERCHANT_CATEGORIES=["Retail","Online Shopping","Grocery","Travel","Restaurant","Utilities","Healthcare","Entertainment","Education","Fuel"]

EMAIL_DOMAINS=["gmail.com","yahoo.com","outlook.com","hotmail.com","rediffmail.com"]


def random_date(start_year=2023,end_year=2026):
    start=datetime(start_year,1,1)
    end=datetime(end_year,8,31)
    delta=end-start
    random_days=random.randint(0,delta.days)
    return (start+timedelta(days=random_days)).strftime("%Y-%m-%d")


def random_email(first,last):
    domain=random.choice(EMAIL_DOMAINS)
    num=random.randint(1,999)
    return f"{first.lower()}.{last.lower()}{num}@{domain}"


def random_mobile():
    return f"9{random.randint(100000000,999999999)}"


def random_ifsc(branch_name):
    bank_codes=["SBIN","HDFC","ICIC","AXIS","PNBK","BARB","BKID","CNRB","UBIN","IOBA"]
    code=random.choice(bank_codes)
    num=random.randint(100000,999999)
    return f"{code}0{num}"



# ─── 1. Generate customers.csv ──────────────────────────────────────────────

def generate_customers():
    filepath=os.path.join(INPUT_DIR,"customers.csv")
    headers=["customer_id","customer_name","email","mobile","city","customer_type","registration_date","status"]

    rows=[]
    used_ids=set()

    # Generate 470 valid records
    for i in range(1,471):
        cid=f"C{i:04d}"
        used_ids.add(cid)
        first=random.choice(FIRST_NAMES)
        last=random.choice(LAST_NAMES)
        name=f"{first} {last}"
        email=random_email(first,last)
        mobile=random_mobile()
        city=random.choice(CITIES)
        ctype=random.choice(CUSTOMER_TYPES)
        reg_date=random_date(2020,2026)
        status=random.choice(["Active","Inactive"])
        rows.append([cid,name,email,mobile,city,ctype,reg_date,status])

    # Generate 30 invalid records
    invalid_rows=[]

    # 6 missing customer_id
    for _ in range(6):
        first=random.choice(FIRST_NAMES)
        last=random.choice(LAST_NAMES)
        invalid_rows.append(["",f"{first} {last}",random_email(first,last),random_mobile(),random.choice(CITIES),random.choice(CUSTOMER_TYPES),random_date(),"Active"])

    # 5 missing customer_name
    for i in range(471,476):
        invalid_rows.append([f"C{i:04d}","",random_email("test","user"),random_mobile(),random.choice(CITIES),random.choice(CUSTOMER_TYPES),random_date(),"Active"])

    # 5 duplicate customer_id
    dup_ids=random.sample(list(used_ids),5)
    for cid in dup_ids:
        first=random.choice(FIRST_NAMES)
        last=random.choice(LAST_NAMES)
        invalid_rows.append([cid,f"{first} {last}",random_email(first,last),random_mobile(),random.choice(CITIES),random.choice(CUSTOMER_TYPES),random_date(),"Active"])

    # 5 invalid email
    for i in range(476,481):
        first=random.choice(FIRST_NAMES)
        last=random.choice(LAST_NAMES)
        invalid_emails=["invalid-email","noatsign.com","@nodomain","test@@gmail.com",""]
        invalid_rows.append([f"C{i:04d}",f"{first} {last}",random.choice(invalid_emails),random_mobile(),random.choice(CITIES),random.choice(CUSTOMER_TYPES),random_date(),"Active"])

    # 5 invalid mobile
    for i in range(481,486):
        first=random.choice(FIRST_NAMES)
        last=random.choice(LAST_NAMES)
        invalid_mobiles=["12345","abcdefghij","98765","123456789012345",""]
        invalid_rows.append([f"C{i:04d}",f"{first} {last}",random_email(first,last),random.choice(invalid_mobiles),random.choice(CITIES),random.choice(CUSTOMER_TYPES),random_date(),"Active"])

    # 4 invalid customer_type
    for i in range(486,490):
        first=random.choice(FIRST_NAMES)
        last=random.choice(LAST_NAMES)
        invalid_rows.append([f"C{i:04d}",f"{first} {last}",random_email(first,last),random_mobile(),random.choice(CITIES),"InvalidType",random_date(),"Active"])

    rows.extend(invalid_rows)
    random.shuffle(rows)

    with open(filepath,"w",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)

    print(f"Generated customers.csv: {len(rows)} records ({len(rows)-30} valid, 30 invalid)")
    return used_ids


# ─── 2. Generate branches.csv ───────────────────────────────────────────────

def generate_branches():
    filepath=os.path.join(INPUT_DIR,"branches.csv")
    headers=["branch_id","branch_name","city","state","manager_name","ifsc_code","status"]

    rows=[]
    used_ids=set()
    branch_data=[]

    # 47 valid records
    for i in range(1,48):
        bid=f"B{i:03d}"
        used_ids.add(bid)
        city_idx=i%len(CITIES)
        city=CITIES[city_idx]
        state=STATES[city_idx]
        branch_name=f"{city} Main Branch {i}"
        first=random.choice(FIRST_NAMES)
        last=random.choice(LAST_NAMES)
        manager=f"{first} {last}"
        ifsc=random_ifsc(branch_name)
        status=random.choice(["Active","Inactive"])
        rows.append([bid,branch_name,city,state,manager,ifsc,status])
        branch_data.append({"branch_id":bid,"city":city})

    # 3 invalid records
    invalid_rows=[]

    # 1 missing branch_id
    invalid_rows.append(["","Delhi Central Branch","Delhi","Delhi","Rahul Sharma","SBIN012345","Active"])

    # 1 duplicate branch_id
    dup_id=random.choice(list(used_ids))
    invalid_rows.append([dup_id,"Duplicate Branch","Mumbai","Maharashtra","Test Manager","HDFC099999","Active"])

    # 1 missing branch_name + invalid IFSC
    invalid_rows.append(["B048","","Pune","Maharashtra","","INVALID","Active"])

    rows.extend(invalid_rows)
    random.shuffle(rows)

    with open(filepath,"w",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)

    print(f"Generated branches.csv: {len(rows)} records (47 valid, 3 invalid)")
    return branch_data


# ─── 3. Generate accounts.csv ───────────────────────────────────────────────

def generate_accounts(valid_customer_ids,branch_data):
    filepath=os.path.join(INPUT_DIR,"accounts.csv")
    headers=["account_id","customer_id","account_type","branch_id","balance","opening_date","account_status"]

    rows=[]
    used_ids=set()
    account_balances={}

    customer_list=sorted(list(valid_customer_ids))

    # 570 valid records
    for i in range(1,571):
        aid=f"A{i:04d}"
        used_ids.add(aid)
        cid=random.choice(customer_list)
        atype=random.choice(ACCOUNT_TYPES)
        bid=random.choice(branch_data)["branch_id"]
        balance=round(random.uniform(1000,5000000),2)
        opening_date=random_date(2018,2026)
        status=random.choice(["Active","Inactive","Frozen"])
        rows.append([aid,cid,atype,bid,balance,opening_date,status])
        account_balances[aid]=balance

    # 30 invalid records
    invalid_rows=[]

    # 6 missing account_id
    for _ in range(6):
        invalid_rows.append(["",random.choice(customer_list),random.choice(ACCOUNT_TYPES),random.choice(branch_data)["branch_id"],round(random.uniform(1000,100000),2),random_date(),"Active"])

    # 5 duplicate account_id
    dup_ids=random.sample(list(used_ids),5)
    for aid in dup_ids:
        invalid_rows.append([aid,random.choice(customer_list),random.choice(ACCOUNT_TYPES),random.choice(branch_data)["branch_id"],round(random.uniform(1000,100000),2),random_date(),"Active"])

    # 5 customer does not exist
    for i in range(571,576):
        invalid_rows.append([f"A{i:04d}","C9999",random.choice(ACCOUNT_TYPES),random.choice(branch_data)["branch_id"],round(random.uniform(1000,100000),2),random_date(),"Active"])

    # 5 negative balance
    for i in range(576,581):
        invalid_rows.append([f"A{i:04d}",random.choice(customer_list),random.choice(ACCOUNT_TYPES),random.choice(branch_data)["branch_id"],-round(random.uniform(100,10000),2),random_date(),"Active"])

    # 5 invalid account_type
    for i in range(581,586):
        invalid_rows.append([f"A{i:04d}",random.choice(customer_list),"InvalidType",random.choice(branch_data)["branch_id"],round(random.uniform(1000,100000),2),random_date(),"Active"])

    # 4 invalid opening_date
    for i in range(586,590):
        invalid_rows.append([f"A{i:04d}",random.choice(customer_list),random.choice(ACCOUNT_TYPES),random.choice(branch_data)["branch_id"],round(random.uniform(1000,100000),2),"invalid-date","Active"])

    invalid_rows=invalid_rows[:30]
    rows.extend(invalid_rows)
    random.shuffle(rows)

    with open(filepath,"w",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)

    print(f"Generated accounts.csv: {len(rows)} records (570 valid, 30 invalid)")
    return account_balances


# ─── 4. Generate transactions.csv ───────────────────────────────────────────

def generate_transactions(account_balances):
    filepath=os.path.join(INPUT_DIR,"transactions.csv")
    headers=["transaction_id","account_id","transaction_type","transaction_amount","transaction_date","transaction_mode","merchant_category"]

    rows=[]
    used_ids=set()
    valid_accounts=list(account_balances.keys())

    # 9500 valid records
    for i in range(1,9501):
        tid=f"T{i:05d}"
        used_ids.add(tid)
        aid=random.choice(valid_accounts)
        ttype=random.choice(TRANSACTION_TYPES)
        amount=round(random.uniform(100,500000),2)
        tdate=random_date(2024,2026)
        tmode=random.choice(TRANSACTION_MODES)
        merchant=random.choice(MERCHANT_CATEGORIES)
        rows.append([tid,aid,ttype,amount,tdate,tmode,merchant])

    # 500 invalid records
    invalid_rows=[]

    # 80 missing transaction_id
    for _ in range(80):
        invalid_rows.append(["",random.choice(valid_accounts),random.choice(TRANSACTION_TYPES),round(random.uniform(100,50000),2),random_date(),random.choice(TRANSACTION_MODES),random.choice(MERCHANT_CATEGORIES)])

    # 70 duplicate transaction_id
    dup_ids=random.sample(list(used_ids),70)
    for tid in dup_ids:
        invalid_rows.append([tid,random.choice(valid_accounts),random.choice(TRANSACTION_TYPES),round(random.uniform(100,50000),2),random_date(),random.choice(TRANSACTION_MODES),random.choice(MERCHANT_CATEGORIES)])

    # 70 missing account_id
    for i in range(9501,9571):
        invalid_rows.append([f"T{i:05d}","",random.choice(TRANSACTION_TYPES),round(random.uniform(100,50000),2),random_date(),random.choice(TRANSACTION_MODES),random.choice(MERCHANT_CATEGORIES)])

    # 70 account does not exist
    for i in range(9571,9641):
        invalid_rows.append([f"T{i:05d}","A9999",random.choice(TRANSACTION_TYPES),round(random.uniform(100,50000),2),random_date(),random.choice(TRANSACTION_MODES),random.choice(MERCHANT_CATEGORIES)])

    # 70 negative/zero transaction_amount
    for i in range(9641,9711):
        neg_amount=round(random.uniform(-10000,0),2)
        invalid_rows.append([f"T{i:05d}",random.choice(valid_accounts),random.choice(TRANSACTION_TYPES),neg_amount,random_date(),random.choice(TRANSACTION_MODES),random.choice(MERCHANT_CATEGORIES)])

    # 50 invalid transaction_type
    for i in range(9711,9761):
        invalid_rows.append([f"T{i:05d}",random.choice(valid_accounts),"TRANSFER",round(random.uniform(100,50000),2),random_date(),random.choice(TRANSACTION_MODES),random.choice(MERCHANT_CATEGORIES)])

    # 50 invalid transaction_mode
    for i in range(9761,9811):
        invalid_rows.append([f"T{i:05d}",random.choice(valid_accounts),random.choice(TRANSACTION_TYPES),round(random.uniform(100,50000),2),random_date(),"Telegram",random.choice(MERCHANT_CATEGORIES)])

    # 40 invalid transaction_date
    for i in range(9811,9851):
        invalid_rows.append([f"T{i:05d}",random.choice(valid_accounts),random.choice(TRANSACTION_TYPES),round(random.uniform(100,50000),2),"bad-date",random.choice(TRANSACTION_MODES),random.choice(MERCHANT_CATEGORIES)])

    invalid_rows=invalid_rows[:500]
    rows.extend(invalid_rows)
    random.shuffle(rows)

    with open(filepath,"w",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)

    print(f"Generated transactions.csv: {len(rows)} records (9500 valid, 500 invalid)")


# ─── 5. Generate loans.csv ──────────────────────────────────────────────────

def generate_loans(valid_customer_ids):
    filepath=os.path.join(INPUT_DIR,"loans.csv")
    headers=["loan_id","customer_id","loan_type","loan_amount","interest_rate","loan_start_date","loan_status"]

    rows=[]
    used_ids=set()
    customer_list=sorted(list(valid_customer_ids))

    # 285 valid records
    for i in range(1,286):
        lid=f"L{i:04d}"
        used_ids.add(lid)
        cid=random.choice(customer_list)
        ltype=random.choice(LOAN_TYPES)
        amount=round(random.uniform(50000,10000000),2)
        rate=round(random.uniform(6.5,18.0),2)
        start_date=random_date(2020,2026)
        status=random.choice(LOAN_STATUSES)
        rows.append([lid,cid,ltype,amount,rate,start_date,status])

    # 15 invalid records
    invalid_rows=[]

    # 3 missing loan_id
    for _ in range(3):
        invalid_rows.append(["",random.choice(customer_list),random.choice(LOAN_TYPES),round(random.uniform(50000,1000000),2),round(random.uniform(7,15),2),random_date(),"Active"])

    # 3 missing customer_id
    for i in range(286,289):
        invalid_rows.append([f"L{i:04d}","",random.choice(LOAN_TYPES),round(random.uniform(50000,1000000),2),round(random.uniform(7,15),2),random_date(),"Active"])

    # 2 customer does not exist
    for i in range(289,291):
        invalid_rows.append([f"L{i:04d}","C9999",random.choice(LOAN_TYPES),round(random.uniform(50000,1000000),2),round(random.uniform(7,15),2),random_date(),"Active"])

    # 2 negative loan_amount
    for i in range(291,293):
        invalid_rows.append([f"L{i:04d}",random.choice(customer_list),random.choice(LOAN_TYPES),-round(random.uniform(50000,1000000),2),round(random.uniform(7,15),2),random_date(),"Active"])

    # 2 negative interest_rate
    for i in range(293,295):
        invalid_rows.append([f"L{i:04d}",random.choice(customer_list),random.choice(LOAN_TYPES),round(random.uniform(50000,1000000),2),-round(random.uniform(1,5),2),random_date(),"Active"])

    # 2 invalid loan_type
    for i in range(295,297):
        invalid_rows.append([f"L{i:04d}",random.choice(customer_list),"Crypto Loan",round(random.uniform(50000,1000000),2),round(random.uniform(7,15),2),random_date(),"Active"])

    # 1 duplicate loan_id
    dup_id=random.choice(list(used_ids))
    invalid_rows.append([dup_id,random.choice(customer_list),random.choice(LOAN_TYPES),round(random.uniform(50000,1000000),2),round(random.uniform(7,15),2),random_date(),"Active"])

    invalid_rows=invalid_rows[:15]
    rows.extend(invalid_rows)
    random.shuffle(rows)

    with open(filepath,"w",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)

    print(f"Generated loans.csv: {len(rows)} records (285 valid, 15 invalid)")


# ─── Main ────────────────────────────────────────────────────────────────────

if __name__=="__main__":
    print("="*60)
    print("Generating Banking CSV Data Files")
    print("="*60)

    valid_customer_ids=generate_customers()
    branch_data=generate_branches()
    account_balances=generate_accounts(valid_customer_ids,branch_data)
    generate_transactions(account_balances)
    generate_loans(valid_customer_ids)

    print("="*60)
    print("All CSV files generated successfully in data/input/")
    print("="*60)
